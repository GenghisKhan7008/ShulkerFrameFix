package com.example.shulkerframefix.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2627;

@Mixin(class_2627.class)
public class ShulkerBoxBlockEntityMixin {

    @Redirect(
        method = "pushEntities",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/World;getOtherEntities(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Box;)Ljava/util/List;"
        )
    )
    private List<class_1297> ignoreItemFrames(class_1937 world, class_1297 except, class_238 box) {
        return world.method_8335(except, box).stream()
            .filter(entity -> !(entity instanceof class_1533))
            .collect(Collectors.toList());
    }
}
